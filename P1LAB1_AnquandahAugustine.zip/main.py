first_name = "Pat"
print(f'Hello {first_name} and welcome to CS Online!')

''' Type your code here. '''